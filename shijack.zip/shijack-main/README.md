# shijack

Shijack is a TCP connection hijacking tool for Linux, FreeBSD, and Solaris. Uses Libnet

Download link - https://packetstormsecurity.com/files/24657/shijack.tgz.html

Here is an example of a Shijack command −
root:/home/root/hijack# ./shijack eth0 192.168.0.100 53517 192.168.0.200 23
